# Import the Appointment class from the 'appointment' module and the 'os' module
from appointment import Appointment
import os
 
# Function to create a weekly calendar with predefined days and hours
def create_weekly_calendar():
    days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday']
    hours = ['09', '10', '11', '12', '13', '14', '15', '16']
    i = 0
    # Iterate over days and hours to create appointments and add them to the calendar
    for day in days:
        for hour in hours:
            appointment = Appointment(day, hour)
            calendar.append(appointment)
            i += 1
 
# Function to load previously scheduled appointments from a file
def load_scheduled_appointments():
    print('Starting the Appointment Manager System\nWeekly calendar created')
    # Ask the user if they want to load appointments from a file
    load = input('Would you like to load previously scheduled appointments from a file (Y/N)? ').capitalize()
    if load == 'Y' or load == 'N':
        if load == 'Y':
            # If yes, ask for the filename and attempt to load appointments from the file
            appointment_filename = input('Enter appointment filename: ')
            found = False
            while not found:
                try:
                    file = open(appointment_filename, 'r')
                    app_counter = 0
                    # Iterate through the lines of the file and extract appointment details
                    for appointment in file:
                        app_counter += 1
                        values = appointment.strip().split(',')
                        app_name, app_phone, app_type, app_day, app_time = values
                        # Find the corresponding appointment in the calendar and schedule it
                        appointment = find_appointment_by_time(app_day, app_time)
                        if appointment is not None:
                            appointment.schedule(app_name, app_phone, app_type)
                        else:
                            pass
                    print(f"{app_counter} previously scheduled appointments have been loaded")
                    found = True
                except FileNotFoundError:
                    # If the file is not found, ask the user to re-enter the filename
                    appointment_filename = input(f"File not found. Re-enter appointment filename: ")
 
# Function to print the menu options
def print_menu():
    print('\nJojo\'s Hair Salon Appointment Manager')
    print('======================================')
    print(' 1) Schedule an appointment')
    print(' 2) Find appointment by name')
    print(' 3) Print Calendar for a specific day')
    print(' 4) Cancel an appointment')
    print(' 9) Exit the system')
    option = input('Enter your selection: ')
    # Ensure the user enters a valid option
    while option not in ['1', '2', '3', '4', '9']:
        option = input('Invalid!\nEnter your selection: ')
    return option
 
# Function to find an appointment in the calendar by day and start hour
def find_appointment_by_time(day, start_hour):
    result = None
    day = str().title  # This line seems to be a mistake, it doesn't modify 'day'
    # Iterate through the calendar and find the matching appointment
    for appointment in calendar:
        if appointment.day_of_week == day and appointment.start_time_hour == start_hour:
            result = appointment
    return result
 
# Function to display appointments for a specific client name
def show_appointments_by_name(name):
    print(f"Appointments for {name}")
    print(f"{'Client Name':15}{'Phone':15} {'Day':12} {'Start':>5} - {'End'}{'Type':>19}")
    print("-" * 85)
 
    found_appointments = False
    # Iterate through the calendar and print appointments for the specified client name
    for appointment in calendar:
        if appointment.get_client_name().lower() == name.lower():
            print(appointment)
            found_appointments = True
    if not found_appointments:
        print("No appointments found.")
 
# Function to display appointments for a specific day
def show_appointments_by_day(day):
    print(f"Appointments for {day}")
    print(f"{'Client Name':15}{'Phone':15} {'Day':12} {'Start':>5} - {'End'}{'Type':>19}")
    print("-" * 85)
 
    # Iterate through the calendar and print appointments for the specified day
    for appointment in calendar:
        if appointment.day_of_week.lower() == day.lower():
            print(appointment)
 
# Function to save scheduled appointments to a file
def save_scheduled_appointments(filename):
    if not filename.endswith('.csv'):
        filename += '.csv'
 
    file = open(filename, 'w')
 
    for appointment in calendar:
        if appointment.get_client_name() == '':
            pass
        else:
           
            file.write(f'{appointment.format_record()}\n')
 
# Main function to run the appointment manager system
def main():
    global calendar
    calendar = []  # Initialize the calendar as an empty list
    create_weekly_calendar()
    load_scheduled_appointments()
    exit_program = False
    while not exit_program:
        option = print_menu()
        if option == '1':
            print('**Schedule an appointment **')
            app_day = input('\nEnter the day: ')
            app_time = input('Enter the start hour (24-hour clock): ')
            app_name = input('Client Name: ')
            app_phone = input('Client Phone: ')
            app_type = input('Appointment types\n1: Mens Cut $50, 2: Ladies Cut $80, 3: Mens Colouring $50, '
                             '4: Ladies Colouring $120: ')
            print(f'OK, {app_name}s appointment is scheduled\n')
            # Find the corresponding appointment in the calendar and schedule it
            appointment = find_appointment_by_time(app_day, app_time)
            if appointment is not None:
                appointment.schedule(app_name, app_phone, app_type)
            else:
                pass
 
        elif option == '2':
            client_name_input = input('Enter Client Name: ')
            show_appointments_by_name(client_name_input.title())
 
        elif option == '3':
            day = False
            while not day:
                day_input = input('Enter day of the week: ').title()
                if day_input in ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']:
                    show_appointments_by_day(day_input)
                    day = True
                else:
                    print("Please enter a valid day.")
 
        elif option == '4':
            print('** Cancel an appointment **')
            app_day = input('What day: ')
            app_time