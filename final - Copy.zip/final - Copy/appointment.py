class Appointment:
 
    # Constructor method to initialize an appointment with day_of_week and start_time_hour
    def __init__(self, day_of_week, start_time_hour):
        self.__client_name = ''
        self.__client_phone = ''
        self.__appt_type = ''
        self.day_of_week = day_of_week
        self.start_time_hour = start_time_hour
 
    # Method to get a human-readable description of an appointment type
    def get_appt_type_desc(self, appt_type):
        match appt_type:
            case '0':
                return 'Available'
            case '1':
                return 'Mens Cut'
            case '2':
                return 'Ladies Cut'
            case '3':
                return 'Mens Colouring'
            case '4':
                return 'Ladies Colouring'
            case _:
                return 'None'
 
    # Getter methods for various attributes of the appointment
    def get_day_of_week(self):
        return str(self.day_of_week)
 
    def get_start_time_hour(self):
        return str(self.start_time_hour)
 
    def get_end_time_hour(self):
        return str((int(self.start_time_hour) + 1))
 
    def get_client_name(self):
        return self.__client_name
 
    def get_client_phone(self):
        return self.__client_phone
 
    def get_appt_type(self):
        return self.__appt_type
 
    # Setter methods for client_name, client_phone, and appt_type
    def set_client_name(self, name):
        self.__client_name = name
 
    def set_client_phone(self, phone):
        self.__client_phone = phone
 
    def set_appt_type(self, type):
        self.__appt_type = type
 
    # Method to schedule an appointment with client_name, client_phone, and appt_type
    def schedule(self, app_name, app_phone, app_type):
        self.set_client_name(app_name)
        self.set_client_phone(app_phone)
        self.set_appt_type(app_type)
 
    # Method to cancel an appointment by resetting client_name, client_phone, and appt_type
    def cancel(self):
        self.__client_name = ''
        self.__client_phone = ''
        self.__appt_type = ''
 
    # Method to format an appointment record as a string
    def format_record(self):
        return f"{self.__client_name},{self.__client_phone},{self.__appt_type},{self.day_of_week},{self.start_time_hour}"
 
    # Method to format an appointment as a string for display
    def __str__(self):
        self.start_time_hour = str(self.start_time_hour).rjust(2, '0')
        return f"{self.__client_name:15}{self.__client_phone:15} {self.day_of_week:9} {self.start_time_hour:>5}:00 - {self.get_end_time_hour()}:00{self.get_appt_type_desc(self.get_appt_type()):>17}"
 
# Import the Appointment class from the 'appointment' module and the 'os' module
from appointment import Appointment
import os
 
# Function to create a weekly calendar with predefined days and hours
def create_weekly_calendar():
    days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday']
    hours = ['09', '10', '11', '12', '13', '14', '15', '16']